Codes of IEAIE

cipher: entropy.m decrypt.m
cryptanalysis: cpa.m