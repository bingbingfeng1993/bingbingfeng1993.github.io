function v=attackHorizontal(I,C)

end